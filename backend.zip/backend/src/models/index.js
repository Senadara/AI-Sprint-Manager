// Import associations to ensure all relationships are properly set up
const models = require('./associations');

module.exports = models;
